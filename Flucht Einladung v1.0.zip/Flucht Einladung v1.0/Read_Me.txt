Introduction:
	- This is a game developed by a group of students of "University of Applied Sciences Europe". 
	- The game is made by Juan C. Osorio A., Geumseong Han, Lenny Steve Jox 
	- The aim of the game is to give the correct paper to the correct people
	- Run “Flucht Einladung.exe” to play the game

How to Pay:
	- Click and drag code into mail slot
